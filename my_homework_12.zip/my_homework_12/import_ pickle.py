import pickle
import sys

class Contact:
    def __init__(self, name, phone, email=None):
        self.name = name
        self.phone = phone
        self.email = email

    def __repr__(self):
        return f"{self.name} (тел: {self.phone}" + (f", email: {self.email})" if self.email else ")")

class AddressBook:
    def __init__(self):
        # Зберігаємо контакти у словнику: ключ — ім’я, значення — Contact
        self.contacts = {}

    def add_contact(self, name, phone, email=None):
        self.contacts[name] = Contact(name, phone, email)

    def remove_contact(self, name):
        if name in self.contacts:
            del self.contacts[name]
        else:
            print(f"Контакт «{name}» не знайдено.")

    def list_contacts(self):
        if not self.contacts:
            print("Адресна книга порожня.")
        for c in self.contacts.values():
            print(c)

    def find_contact(self, name):
        return self.contacts.get(name, None)

def save_data(book: AddressBook, filename="addressbook.pkl"):
    """Серіалізує AddressBook у файл."""
    with open(filename, "wb") as f:
        pickle.dump(book, f)

def load_data(filename="addressbook.pkl"):
    """Десеріалізує AddressBook з файла або створює новий, якщо файл не знайдено."""
    try:
        with open(filename, "rb") as f:
            return pickle.load(f)
    except FileNotFoundError:
        return AddressBook()

def main():
    book = load_data()

    while True:
        print("\nМеню:")
        print("1. Додати контакт")
        print("2. Видалити контакт")
        print("3. Показати всі контакти")
        print("4. Знайти контакт")
        print("5. Вихід")
        choice = input("Виберіть дію (1-5): ").strip()

        if choice == "1":
            name = input("Ім’я: ").strip()
            phone = input("Телефон: ").strip()
            email = input("Email (необов’язково): ").strip() or None
            book.add_contact(name, phone, email)
            print("Контакт додано.")

        elif choice == "2":
            name = input("Ім’я контакту для видалення: ").strip()
            book.remove_contact(name)

        elif choice == "3":
            book.list_contacts()

        elif choice == "4":
            name = input("Ім’я для пошуку: ").strip()
            contact = book.find_contact(name)
            print(contact if contact else "Контакт не знайдено.")

        elif choice == "5":
            # Перед виходом зберігаємо всі дані
            save_data(book)
            print("Дані збережені. До зустрічі!")
            sys.exit(0)

        else:
            print("Невірний вибір, спробуйте ще раз.")

if __name__ == "__main__":
    main()